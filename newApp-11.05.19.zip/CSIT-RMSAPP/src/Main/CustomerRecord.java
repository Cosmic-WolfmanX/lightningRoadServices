/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Main;

/**
 *
 * @author jmfio
 */
public class CustomerRecord {
    
    
    public int id;
    public String customerFirstName;
    public String customerLastName;
    public String username;
    public String password;
    public String email;
    public int phoneNum;
    public int creditCardNum;
    public int cvv;
    public String creditCardExpiryDate;
    public int membershipStatus;
    public String nameOnCreditCard;
    public Car car;
    
 
    
}