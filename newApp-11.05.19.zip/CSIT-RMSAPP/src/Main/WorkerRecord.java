/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Main;

/**
 *
 * @author jmfio
 */
public class WorkerRecord {
    public int id;
    public String workerFirstName;
    public String workerLastName;
    public String email;
    public String username;
    public String password;
    public int phoneNum;
    
}
