/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Main;
import java.net.URL;

/**
 *
 * @author jmfio
 */
public class Global {
    public static DataCollection data = new DataCollection();
    public static currentUser user;
    public static URL customerRecordsURL;
    public static URL carsURL;
    public static URL workerRecordsURL;
    
}
    
