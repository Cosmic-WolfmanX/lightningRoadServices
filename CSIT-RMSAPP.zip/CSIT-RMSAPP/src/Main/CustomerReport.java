/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Main;

/**
 *
 * @author jmfio
 */
public class CustomerReport {
    
    public int customerID;
    public int workerID;
    public String dateOccured;
    public String location;
    public String incidentDetails;
    public String repairsGiven;
    public int rating;
    public String feedback;
    
}
